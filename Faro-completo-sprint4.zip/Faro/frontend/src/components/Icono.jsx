// Iconos decorativos: las acciones siempre tienen también una etiqueta de texto.
const trazos = {
  lugar: 'M20 10c0 6-8 11-8 11S4 16 4 10a8 8 0 1 1 16 0Z M15 10a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z',
  infraestructura: 'M3 21h18 M5 21V9h6v12 M11 21V3h8v18 M8 12v1 M8 16v1 M15 7v1 M15 11v1 M15 15v1',
  agregar: 'M12 5v14 M5 12h14',
  guardar: 'M20 6 9 17l-5-5',
  editar: 'm16 3 5 5-12 12-6 1 1-6Z M14 5l5 5',
  borrar: 'M3 6h18 M9 6V3h6v3 M5 6l1 15h12l1-15 M10 10v7 M14 10v7',
  cuadrilla: 'M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2 M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8Z M22 21v-2a4 4 0 0 0-3-3.87 M16 3.13a4 4 0 0 1 0 7.75',
  orden: 'M9 3h6v3H9Z M9 4.5H6V21h12V4.5h-3 M9 11h6 M9 15h6 M9 19h3',
  historia: 'M3 12a9 9 0 1 0 2.64-6.36L3 8 M3 3v5h5 M12 7v5l3 2',
  volver: 'M19 12H5 M11 18l-6-6 6-6',
  tareas: 'M9 3h6v3H9Z M9 4.5H6V21h12V4.5h-3 M9 14l2 2 4-4',
  iniciar: 'M8 5v14l11-7Z',
  mapa: 'M9 4 3 6v14l6-2 6 2 6-2V4l-6 2-6-2Z M9 4v14 M15 6v14',
  historial: 'M12 7v5l3 2 M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z',
  abajo: 'm6 9 6 6 6-6',
  mas: 'M4 7h16 M4 12h16 M4 17h16',
  cerrar: 'M18 6 6 18 M6 6l12 12',
  buscar: 'M11 18a7 7 0 1 1 0-14 7 7 0 0 1 0 14Z M20 20l-3.5-3.5',
  lista: 'M8 6h13 M8 12h13 M8 18h13 M3 6h.01 M3 12h.01 M3 18h.01',
  // Usuarios (gestión del personal)
  usuario: 'M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2 M12 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8Z',
  clave: 'M7.5 15.5a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7Z M10.5 12H21 M18 12v3 M15 12v2',
  baja: 'M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2 M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8Z M17 11h5',
  // Tipos de lugar (lista del mapa)
  luminaria: 'M9 18h6 M10 21h4 M12 3a6 6 0 0 0-4 10.5c.7.7 1 1.5 1 2.5h6c0-1 .3-1.8 1-2.5A6 6 0 0 0 12 3Z',
  espacioVerde: 'M12 22V12 M12 12c-4 0-6-3-6-6 3 0 6 2 6 6Z M12 12c4 0 6-3 6-6-3 0-6 2-6 6Z',
  calle: 'M4 21 9 3 M20 21 15 3 M12 5v2 M12 11v2 M12 17v2',
  // Mantenimiento periódico y Auditoría (Sprint 4)
  mantenimiento: 'M14.7 6.3a4 4 0 0 1-5.4 5.4L4 17l3 3 5.3-5.3a4 4 0 0 1 5.4-5.4l-3 3-2-2Z',
  auditoria: 'M9 3h6v3H9Z M9 4.5H6V21h12V4.5h-3 M9 10h6 M9 14l1.5 1.5L14 12',
  // Reportes e indicadores (Sprint 4)
  reportes: 'M3 3v18h18 M7 16v-4 M12 16V8 M17 16v-7',
  descargar: 'M12 4v11 M7 10l5 5 5-5 M5 20h14',
  pausar: 'M9 5v14 M15 5v14',
}

function Icono({ nombre, className = '' }) {
  return (
    <svg className={`icono ${className}`} viewBox="0 0 24 24" fill="none"
      stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"
      aria-hidden="true" focusable="false">
      <path d={trazos[nombre]} />
    </svg>
  )
}

export default Icono