import { useEffect, useRef } from 'react'
import L from 'leaflet'
import 'leaflet/dist/leaflet.css'
import { colorDelResumen, radioDelResumen } from '../utils/mapa'
import { contarTrabajos } from '../utils/listaLugares'
import { CENTRO_PUEBLO, ZONA_PUEBLO } from '../utils/zona'

// RNF10: el mapa lo da un servicio externo. Se usa OpenStreetMap con Leaflet: es gratuito y no pide clave.
// Los mosaicos públicos de OSM son para un uso moderado: si el uso crece, hay que pasar a un proveedor propio.
const URL_MOSAICOS = 'https://tile.openstreetmap.org/{z}/{x}/{y}.png'
const ATRIBUCION = '&copy; Colaboradores de <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
// Solo se usa si todavía no hay lugares para encuadrar: la plaza principal de Estación General Paz.
// Leaflet pide [latitud, longitud] (al revés que GeoJSON, que guarda [longitud, latitud]).
const CENTRO_POR_DEFECTO = [CENTRO_PUEBLO.latitud, CENTRO_PUEBLO.longitud]
// La zona del pueblo (utils/zona.js): el mapa no deja moverse fuera de ella.
const LIMITES_PUEBLO = [[ZONA_PUEBLO.sur, ZONA_PUEBLO.oeste], [ZONA_PUEBLO.norte, ZONA_PUEBLO.este]]

// La etiqueta que aparece arriba de cada lugar ("Plaza principal · 2 trabajos abiertos").
// Se arma con textContent (nunca con HTML): los nombres los escriben usuarios.
// Los detalles del lugar no van en un globo sobre el mapa: se ven en la ficha, al costado.
function crearEtiqueta(resumen) {
  const texto = document.createElement('span')
  texto.textContent = `${resumen.lugar.nombre} · ${contarTrabajos(resumen.ordenes.length)}`
  return texto
}

// Props:
// - resumenes: lo que se dibuja, un elemento por lugar (ver agruparPorLugar en utils/mapa.js)
// - modoColor: 'prioridad' o 'estado'
// - limites: { sur, oeste, norte, este } para encuadrar el mapa cuando cambian (o null)
// - seleccion: { lugarId, vez } → centra el mapa en ese lugar y muestra su etiqueta (vez cambia aunque se repita el lugar)
// - onSeleccionar(lugarId): se tocó un lugar en el mapa
// - onLimites(zona): el mapa se movió; zona = { sur, oeste, norte, este } de lo que se ve
// Para agregar un lugar nuevo tocando el mapa:
// - agregando: true mientras se está eligiendo dónde va (el cursor cambia y tocar un lugar no abre su ficha)
// - puntoNuevo: { latitud, longitud } donde va el pin del lugar nuevo (o null)
// - onElegirPunto(punto): se tocó el mapa o se soltó el pin después de arrastrarlo
// - hojaAbajo: (celular) ref de la hoja del formulario que sube desde abajo y tapa parte del mapa
// Las marcas del mapa no se pueden recorrer con el teclado: la lista que acompaña al mapa tiene los mismos datos.
function MapaLugares({ resumenes, modoColor, limites, seleccion, onSeleccionar, onLimites, agregando = false, puntoNuevo = null, onElegirPunto, hojaAbajo = null }) {
  const contenedor = useRef(null)
  const mapa = useRef(null)
  const grupo = useRef(null)
  const capasPorLugar = useRef(new Map())
  const avisos = useRef({})
  const pinNuevo = useRef(null)

  // Los avisos siempre apuntan a las funciones y datos más nuevos de la página.
  useEffect(() => {
    avisos.current = { onSeleccionar, onLimites, onElegirPunto, agregando }
  })

  // Crear el mapa una sola vez.
  useEffect(() => {
    const capas = capasPorLugar.current
    // maxBounds + maxBoundsViscosity 1: si se arrastra el mapa fuera del pueblo, vuelve ("rebota").
    const instancia = L.map(contenedor.current, {
      center: CENTRO_POR_DEFECTO, zoom: 14, maxBounds: LIMITES_PUEBLO, maxBoundsViscosity: 1,
    })
    // Zoom mínimo: el que muestra la zona entera en el tamaño actual del mapa (no deja alejarse más).
    // Se recalcula cuando cambia el tamaño (celular, compu, ficha abierta o cerrada).
    const ajustarZoomMinimo = () => instancia.setMinZoom(instancia.getBoundsZoom(LIMITES_PUEBLO, true))
    ajustarZoomMinimo()
    L.tileLayer(URL_MOSAICOS, { maxZoom: 19, attribution: ATRIBUCION }).addTo(instancia)
    grupo.current = L.layerGroup().addTo(instancia)
    mapa.current = instancia

    const avisarZona = () => {
      const zona = instancia.getBounds()
      avisos.current.onLimites?.({ sur: zona.getSouth(), oeste: zona.getWest(), norte: zona.getNorth(), este: zona.getEast() })
    }
    instancia.on('moveend', avisarZona)
    avisarZona()

    // Agregar un lugar: tocar el mapa elige el punto (solo mientras se está agregando).
    instancia.on('click', (evento) => {
      if (!avisos.current.agregando) return
      avisos.current.onElegirPunto?.({ latitud: evento.latlng.lat, longitud: evento.latlng.lng })
    })

    // Si la caja del mapa cambia de tamaño (por ejemplo, se abre o se cierra la ficha del lugar al costado),
    // Leaflet tiene que volver a medirla; si no, quedan franjas grises sin mosaicos.
    const observador = new ResizeObserver(() => {
      instancia.invalidateSize()
      ajustarZoomMinimo()
    })
    observador.observe(contenedor.current)

    return () => {
      observador.disconnect()
      instancia.remove()
      mapa.current = null
      grupo.current = null
      pinNuevo.current = null
      capas.clear()
    }
  }, [])

  // Dibujar los lugares cada vez que cambian los datos o el criterio de color.
  useEffect(() => {
    if (!grupo.current) return
    grupo.current.clearLayers()
    capasPorLugar.current.clear()

    for (const resumen of resumenes) {
      const color = colorDelResumen(resumen, modoColor)
      const sinTrabajos = !resumen.principal
      const capa = L.geoJSON({ type: 'Feature', properties: {}, geometry: resumen.lugar.ubicacion }, {
        // Puntos (luminarias): círculo. El tamaño crece con la prioridad.
        pointToLayer: (_, posicion) => L.circleMarker(posicion, {
          radius: radioDelResumen(resumen), color: '#FFFFFF', weight: 2, fillColor: color, fillOpacity: sinTrabajos ? 0.7 : 1,
        }),
        // Líneas (calles) y polígonos (espacios verdes)
        style: () => ({ color, weight: sinTrabajos ? 3 : 6, opacity: sinTrabajos ? 0.7 : 0.95, fillColor: color, fillOpacity: 0.35 }),
      })
      capa.bindTooltip(crearEtiqueta(resumen), { direction: 'top', offset: [0, -8], className: 'etiqueta-lugar' })
      // Mientras se agrega un lugar, tocar uno existente no abre su ficha: el toque sigue al mapa y pone el pin ahí.
      capa.on('click', () => {
        if (!avisos.current.agregando) avisos.current.onSeleccionar?.(resumen.lugar.id)
      })
      capa.addTo(grupo.current)
      capasPorLugar.current.set(resumen.lugar.id, capa)
    }
  }, [resumenes, modoColor])

  // Encuadrar todos los lugares cuando llegan (o cambian).
  useEffect(() => {
    if (!mapa.current || !limites) return
    mapa.current.fitBounds([[limites.sur, limites.oeste], [limites.norte, limites.este]],
      { padding: [32, 32], maxZoom: 17, animate: false })
  }, [limites])

  // Ir a un lugar elegido desde la lista.
  useEffect(() => {
    if (!seleccion || !mapa.current) return
    const capa = capasPorLugar.current.get(seleccion.lugarId)
    if (!capa) return
    // Al elegir un lugar puede abrirse la ficha al costado y el mapa queda más angosto:
    // se mide antes de centrar, así el lugar queda en el medio de lo que se ve.
    mapa.current.invalidateSize({ pan: false })
    const animar = !window.matchMedia('(prefers-reduced-motion: reduce)').matches
    const zona = capa.getBounds()
    if (zona.getSouthWest().equals(zona.getNorthEast())) {
      mapa.current.setView(zona.getCenter(), Math.max(mapa.current.getZoom(), 17), { animate: animar })
    } else {
      mapa.current.fitBounds(zona, { maxZoom: 18, padding: [40, 40], animate: animar })
    }
    capa.openTooltip()
  }, [seleccion])

  // El pin del lugar nuevo: se puede arrastrar para ajustar la posición (también con el teclado, con las flechas).
  useEffect(() => {
    if (!mapa.current) return
    if (!puntoNuevo) {
      pinNuevo.current?.remove()
      pinNuevo.current = null
      return
    }
    const posicion = [puntoNuevo.latitud, puntoNuevo.longitud]
    if (pinNuevo.current) {
      pinNuevo.current.setLatLng(posicion)
    } else {
      // El dibujo del pin es fijo (no lleva datos de usuarios), por eso puede ir como HTML.
      const icono = L.divIcon({ className: 'pin-nuevo', html: '<span></span>', iconSize: [30, 30], iconAnchor: [15, 30] })
      pinNuevo.current = L.marker(posicion, { icon: icono, draggable: true, title: 'Lugar nuevo: arrastralo para ajustar', alt: 'Lugar nuevo' })
        .on('dragend', () => {
          const { lat, lng } = pinNuevo.current.getLatLng()
          avisos.current.onElegirPunto?.({ latitud: lat, longitud: lng })
        })
        .addTo(mapa.current)
    }
    // En el celular el formulario sube desde abajo y tapa parte del mapa: si el pin quedó debajo,
    // corremos el mapa lo justo para que se vea arriba de la hoja (40 px arriba: el alto del pin y un margen).
    const altoTapado = hojaAbajo?.current?.offsetHeight ?? 0
    if (altoTapado > 0) {
      mapa.current.panInside(posicion, { paddingTopLeft: [0, 40], paddingBottomRight: [0, altoTapado + 16] })
    }
  }, [puntoNuevo, hojaAbajo])

  // Mientras se agrega un lugar, el cursor es una cruz. Se usa classList (y no className) porque
  // Leaflet le agrega sus propias clases a este mismo div y React las borraría al cambiar className.
  useEffect(() => {
    contenedor.current?.classList.toggle('mapa-agregando', agregando)
  }, [agregando])

  return (
    <div id="mapa-lugares" ref={contenedor} className="mapa" role="region"
      aria-label="Mapa de lugares y trabajos abiertos. La lista que está junto al mapa tiene los mismos datos en texto." />
  )
}

export default MapaLugares