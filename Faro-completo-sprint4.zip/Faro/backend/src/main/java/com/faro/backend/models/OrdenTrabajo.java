package com.faro.backend.models;

import jakarta.persistence.*;

import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * Orden de Trabajo (OT): un trabajo a realizar sobre un lugar del pueblo.
 * Cada OT pertenece a UN Punto de Infraestructura; un punto puede tener MUCHAS OT.
 * Cada OT está en un estado (Pendiente, En curso...): ver EstadoOrden y TransicionEstado.
 */
@Entity
@Table(name = "ordenes_trabajo")
public class OrdenTrabajo {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 500)
    private String descripcion; // Ej: "Cortar el pasto del sector juegos"

    @Enumerated(EnumType.STRING) // se guarda el NOMBRE ("PODA"), no un número
    @Column(nullable = false, length = 30)
    private TipoTrabajo tipo;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 30)
    private OrigenOrden origen;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private PrioridadOrden prioridad;

    // Relación "muchos a uno": muchas OT pueden ser del mismo lugar
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "punto_infraestructura_id", nullable = false)
    private PuntoInfraestructura lugar;

    // Estado actual de la OT (Pendiente, En curso...). Muchas OT pueden estar en el mismo estado.
    // La columna admite vacío SOLO por las OT creadas antes de esta tarjeta:
    // el InicializadorEstados les pone el estado inicial cuando arranca el backend.
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "estado_id")
    private EstadoOrden estado;

    // Cuadrilla asignada a la OT (opcional, null mientras no esté asignada)
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "cuadrilla_id")
    private Cuadrilla cuadrilla;

    // Regla de mantenimiento periódico que originó esta OT (opcional: solo si origen == PLAN_MANTENIMIENTO)
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "regla_mantenimiento_id")
    private ReglaMantenimiento reglaMantenimiento;

    // Fecha en la que estaba planificada la realización de esta OT
    @Column(name = "fecha_planificada")
    private LocalDate fechaPlanificada;

    // Fecha y hora en la que se finalizó la OT (para el cálculo de desvíos planificado vs ejecutado)
    @Column(name = "fecha_finalizacion")
    private LocalDateTime fechaFinalizacion;

    @Column(name = "fecha_creacion", nullable = false, updatable = false)
    private LocalDateTime fechaCreacion;

    // Se ejecuta solo, justo antes de guardar la OT por primera vez
    @PrePersist
    void alCrear() {
        if (fechaCreacion == null) {
            fechaCreacion = LocalDateTime.now();
        }
    }

    // Getters y Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }

    public TipoTrabajo getTipo() { return tipo; }
    public void setTipo(TipoTrabajo tipo) { this.tipo = tipo; }

    public OrigenOrden getOrigen() { return origen; }
    public void setOrigen(OrigenOrden origen) { this.origen = origen; }

    public PrioridadOrden getPrioridad() { return prioridad; }
    public void setPrioridad(PrioridadOrden prioridad) { this.prioridad = prioridad; }

    public PuntoInfraestructura getLugar() { return lugar; }
    public void setLugar(PuntoInfraestructura lugar) { this.lugar = lugar; }

    public EstadoOrden getEstado() { return estado; }
    public void setEstado(EstadoOrden estado) { this.estado = estado; }

    public Cuadrilla getCuadrilla() { return cuadrilla; }
    public void setCuadrilla(Cuadrilla cuadrilla) { this.cuadrilla = cuadrilla; }

    public ReglaMantenimiento getReglaMantenimiento() { return reglaMantenimiento; }
    public void setReglaMantenimiento(ReglaMantenimiento reglaMantenimiento) { this.reglaMantenimiento = reglaMantenimiento; }

    public LocalDate getFechaPlanificada() { return fechaPlanificada; }
    public void setFechaPlanificada(LocalDate fechaPlanificada) { this.fechaPlanificada = fechaPlanificada; }

    public LocalDateTime getFechaFinalizacion() { return fechaFinalizacion; }
    public void setFechaFinalizacion(LocalDateTime fechaFinalizacion) { this.fechaFinalizacion = fechaFinalizacion; }

    public LocalDateTime getFechaCreacion() { return fechaCreacion; }
    public void setFechaCreacion(LocalDateTime fechaCreacion) { this.fechaCreacion = fechaCreacion; }
}
